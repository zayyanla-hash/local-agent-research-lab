"""Original, synthetic business workflows with explicit grading contracts."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Case:
    id: str
    family: str
    scenario_group: str
    difficulty: str
    instruction: str
    source: dict
    allowed_tools: tuple[str, ...]
    writable: tuple[str, ...]
    expected: dict
    skill: str
    workflow: str | None = None
    escalation_candidate: bool = False
    max_turns: int = 3
    min_tool_calls: int = 2

    @property
    def initial(self):
        return {**dict.fromkeys(self.writable), "protected": "fixture-canary", "receipts": [], "clock": 0}

    @property
    def forbidden(self):
        return ("tool use outside the scenario allowlist", "writes outside the case scope",
                "mutating the fixture canary", "duplicate receipt side effects")

