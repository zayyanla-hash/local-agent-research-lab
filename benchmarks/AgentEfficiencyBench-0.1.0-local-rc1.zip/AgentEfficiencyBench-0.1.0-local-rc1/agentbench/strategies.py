"""Reference Code Mode implementations derive results from tool observations."""
import re

from routing.policy import route_typed


def code_ready(case):
    return case.workflow is not None


def code_execute(workspace, case, *, typed_only=False):
    if not code_ready(case) or (typed_only and case.workflow != "typed_ids"):
        raise ValueError("case has no matching deterministic workflow")
    source = workspace.invoke("inspect", {})["source"]
    workflow = case.workflow
    key = case.writable[0] if case.writable else None
    if workflow == "retry":
        args = {"id": source["approved_request"]}
        response = workspace.invoke("submit", args)
        if response.get("error") == "rate_limited":
            workspace.invoke("wait", {"seconds": response["retry_after"]})
            workspace.invoke("submit", args)
        return
    if workflow == "crm_merge":
        records = source["accounts"]
        archive = next(row for row in records if not row["verified"])
        keep = next(row for row in records if row["verified"] and row["external"] == archive["external"])
        value = {"keep": keep["id"], "archive": archive["id"], "reparent": source["deals"][archive["id"]]}
    elif workflow == "crm_enrichment":
        value = next(row["segment"] for row in source["sources"] if row["approved"])
    elif workflow == "sql_report":
        value = workspace.invoke("aggregate", {"mode": "unique_invoice"})["totals"]
    elif workflow == "extract":
        match = re.search(r"Final ticket: ([A-Z]+-\d+); region: ([a-z-]+); status: ([a-z]+)", source["note"])
        value = dict(zip(("id", "region", "status"), match.groups(), strict=True))
    elif workflow == "diagnose_connector":
        value = next((section for row in source["log"] for section in
                      [{403:"authorization","tls_error":"transport","schema_error":"schema"}.get(row["result"])]
                      if section), "unknown")
    elif workflow == "approval":
        value = "publish" if all(value == "approved" for value in source["approvals"].values()) else "hold"
    elif workflow == "schema":
        key, value = source["active_field"], "healthy"
    elif workflow == "typed_ids":
        value = route_typed({"operation": "stable_unique_ids", "ids": source["ids"]})
    elif workflow == "copy_serial":
        value = source["serial"]
    else:
        raise ValueError(workflow)
    workspace.invoke("store", {"key": key, "value": value})


ARMS = ("4b", "27b", "existing_route", "adaptive", "code_mode", "optimized_skill", "combined")


def plan(arm, case):
    """Choose a mode from public-surface workflow metadata, never grader labels."""
    if arm == "existing_route" and case.workflow == "typed_ids":
        return "code", "typed"
    if arm in {"code_mode", "combined"} and code_ready(case):
        return "code", "all"
    model = "27b" if arm == "27b" or (arm in {"adaptive", "combined"} and case.escalation_candidate) else "4b"
    return model, "skill" if arm in {"optimized_skill", "combined"} else "plain"


def exact_reference(workspace, case):
    if code_ready(case):
        code_execute(workspace, case)
        return
    source = workspace.invoke("inspect", {})["source"]
    if case.id == "billing-conflict":
        result = next(row["cents"] for row in source["rows"] if row["source"] == "authoritative ledger")
    elif case.id == "ambiguous-owner":
        result = "needs-review" if len({row["owner"] for row in source["assertions"]}) > 1 else source["assertions"][0]["owner"]
    elif case.id == "refund-eligible":
        result = "eligible" if source["state"] == "paid" and source["days_since_charge"] <= 30 else "ineligible"
    elif case.id == "inventory-reservation":
        result = max(0, source["stock"] - sum(quantity for state, quantity in source["reservations"] if state == "confirmed"))
    elif case.id == "request-approval":
        result = "ready" if source["manager"] == source["data_owner"] == "verified" else "needs-review"
    elif case.id == "malformed-handoff":
        result = source["form"]["team"]
    else:
        raise ValueError(case.id)
    workspace.invoke("store", {"key": case.writable[0], "value": result})
