"""Replay simulated workflows and compare matched prompt-skill observations."""
import argparse
from contextlib import closing
from dataclasses import fields
import json
import math
from pathlib import Path
from statistics import median

from agentbench.cases import Case
from agentbench.gateway import Workspace
from agentbench.strategies import exact_reference
from runner.scoring import strict_object

FIXTURES = Path(__file__).resolve().parent / "fixtures"
VERSION = "0.1.0"
RULES = (
    "Use one mock tool call in raw JSON each turn. The format is "
    '{"tool":"inspect","args":{}}. No Markdown or prose. '
    "Use inspect to read records when needed. A store command writes only one task-scoped record: "
    '{"tool":"store","args":{"key":"KEY","value":"VALUE"}}. '
    "The gateway ends the task once the write or receipt succeeds."
)
TOOLS = ("inspect: {}", "store: {key, value}", "aggregate: {mode: unique_invoice or joined_tags}",
         "submit: {id}", "wait: {seconds}")


def records(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def load(path):
    rows = records(path)
    ids = {row["id"] for row in rows}
    if not rows or len(ids) != len(rows):
        raise ValueError("Expected unique case IDs and at least one case")
    return {row["id"]: Case(**{field.name: tuple(row[field.name]) if field.name in {"allowed_tools", "writable"}
                               else row[field.name] for field in fields(Case)})
            for row in rows}


def prompt(case, variant):
    tools = ". ".join(desc for desc in TOOLS if desc.split(":")[0] in case.allowed_tools)
    suffix = "\nWorkflow skill v1: " + case.skill + " Return exactly one raw JSON object." if variant == "skill" else ""
    return RULES + "\nAvailable mock tools: " + tools + "\nTask: " + case.instruction + suffix


def replay(case, stages):
    if len(stages) > case.max_turns:
        raise ValueError(f"{case.id}: too many stages")
    failure = None
    with closing(Workspace(case)) as workspace:
        for stage in stages:
            if workspace.complete or failure:
                raise ValueError(f"{case.id}: trace continued after terminal state")
            body = strict_object(stage["raw_output"])
            if stage["finish"] != "stop":
                failure = "token_exhausted" if stage["finish"] == "length" else "inference_error"
            elif (not body or body.keys() != {"tool", "args"} or not isinstance(body["tool"], str)
                  or not isinstance(body["args"], dict)):
                failure = "invalid_tool_json"
            else:
                workspace.invoke(body["tool"], body["args"])
        if not workspace.complete and failure is None:
            failure = "turn_budget_exhausted"
        grade = workspace.grade()
        if not grade["strict_success"] and failure is None:
            failure = "wrong_final_state"
        return {**grade, "failure": failure, "tool_calls": len(workspace.events)}


def score(cases, rows):
    ids = [row["case"] for row in rows]
    if len(ids) != len(set(ids)) or set(ids) != set(cases):
        raise ValueError("traces must cover each case exactly once")
    grades = []
    for row in rows:
        if not isinstance(row["stages"], list) or not row["stages"]:
            raise ValueError(f"{row['case']}: a nonempty list of recorded stages is required")
        if type(row["wall_ms"]) not in (int, float) or not math.isfinite(row["wall_ms"]) or row["wall_ms"] < 0:
            raise ValueError(f"{row['case']}: invalid task wall time")
        for stage in row["stages"]:
            if not isinstance(stage["raw_output"], str) or not isinstance(stage["finish"], str):
                raise ValueError(f"{row['case']}: invalid stage metadata")
            if any(type(stage[key]) is not int or stage[key] < 0 for key in ("prompt_tokens", "output_tokens")):
                raise ValueError(f"{row['case']}: invalid token counters")
        grade = replay(cases[row["case"]], row["stages"])
        grades.append({"case": row["case"], **grade, "wall_ms": row["wall_ms"],
                       "model_calls": len(row["stages"]),
                       **{key: sum(stage[key] for stage in row["stages"]) for key in ("prompt_tokens", "output_tokens")}})
    return grades


def summarize(grades):
    successes = sum(row["strict_success"] for row in grades)
    totals = {k: sum(row[k] for row in grades)
              for k in ("model_calls", "tool_calls", "tool_errors", "redundant_reads", "prompt_tokens", "output_tokens")}
    return {"cases": len(grades), "strict_successes": successes,
            "forbidden_effects": sum(row["forbidden_effect"] for row in grades), **totals,
            "task_wall_ms_median": median(row["wall_ms"] for row in grades),
            "task_wall_ms_per_success": sum(row["wall_ms"] for row in grades) / successes if successes else None,
            "tokens_per_success": (totals["prompt_tokens"] + totals["output_tokens"]) / successes if successes else None}


def compare(cases, baseline, candidate):
    left, right = (score(cases, rows) for rows in (baseline, candidate))
    left_pass = {row["case"] for row in left if row["strict_success"]}
    right_pass = {row["case"] for row in right if row["strict_success"]}
    return {"baseline": summarize(left), "skill": summarize(right),
            "resolved": sorted(right_pass - left_pass), "new_failures": sorted(left_pass - right_pass),
            "common_successes": len(left_pass & right_pass)}


def reference(cases):
    result = []
    for case in cases.values():
        with closing(Workspace(case)) as workspace:
            exact_reference(workspace, case)
            result.append({"case": case.id, **workspace.grade(), "tool_calls": len(workspace.events)})
    return result


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--version", action="version", version=VERSION)
    sub = cli.add_subparsers(dest="mode", required=True)
    for mode in ("cases", "reference", "score", "skill"):
        parser = sub.add_parser(mode)
        parser.add_argument("--cases", type=Path, default=FIXTURES / "smoke.jsonl")
        if mode == "cases":
            parser.add_argument("--variant", default="plain", choices=("plain", "skill"))
        if mode in {"score", "skill"}:
            parser.add_argument("traces", type=Path)
        if mode == "skill":
            parser.add_argument("skill_traces", type=Path)
    sub.add_parser("sample", help="replay fictional paired traces and deterministic references")
    args = cli.parse_args()
    try:
        if args.mode == "sample":
            cases = load(FIXTURES / "smoke.jsonl")
            refs = reference(cases)
            pairing = compare(cases, records(FIXTURES / "control.jsonl"),
                              records(FIXTURES / "candidate.jsonl"))
            result = {"reference": {"passed": sum(row["strict_success"] for row in refs),
                                    "cases": len(refs)},
                      "synthetic_skill_efficiency": pairing}
        else:
            cases = load(args.cases)
            if args.mode == "cases":
                result = [{"case": case.id, "prompt": prompt(case, args.variant), "max_turns": case.max_turns}
                          for case in cases.values()]
            elif args.mode == "reference":
                result = reference(cases)
            elif args.mode == "score":
                grades = score(cases, records(args.traces))
                result = {"summary": summarize(grades), "grades": grades}
            else:
                result = compare(cases, records(args.traces), records(args.skill_traces))
        print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    except (KeyError, TypeError, ValueError, OSError) as exc:
        cli.error(str(exc))


if __name__ == "__main__":
    main()
