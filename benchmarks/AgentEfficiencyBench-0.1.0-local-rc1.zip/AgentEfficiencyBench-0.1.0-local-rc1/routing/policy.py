"""First-seen ID deduplication for explicitly typed requests."""
from runner.speed import route


def route_typed(request: object) -> str | None:
    """Return exact line output, including empty output, or defer the request."""
    if not isinstance(request, dict):
        return None
    if request.keys() - {"operation", "ids", "order", "output_format"}:
        return None
    if request.get("operation") != "stable_unique_ids":
        return None
    if request.get("order", "first_seen") != "first_seen":
        return None
    if request.get("output_format", "lines") != "lines":
        return None
    if request.get("ids") == []:
        return ""
    return route(request)
