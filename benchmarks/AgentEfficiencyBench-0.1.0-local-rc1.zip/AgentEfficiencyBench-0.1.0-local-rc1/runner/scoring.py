import json
import re


def strict_object(text):
    def reject_duplicates(items):
        if len(dict(items)) != len(items):
            raise ValueError("duplicate key")
        return dict(items)
    def reject_constant(value):
        raise ValueError(value)
    try:
        obj = json.loads(text, object_pairs_hook=reject_duplicates, parse_constant=reject_constant)
    except (TypeError, ValueError):
        return None
    return obj if isinstance(obj, dict) else None


def grade(case, output):
    raw = output.get("raw_output") or ""
    target = case["target"]
    valid = None
    if case["kind"] == "json":
        obj = strict_object(raw)
        valid = obj is not None and obj.keys() == target.keys() and all(type(obj[k]) is type(v) for k,v in target.items())
        success = valid and obj == target
    elif case["kind"] == "tool":
        calls = output.get("tool_calls", [])
        wrapper = re.fullmatch(r"\s*<tool_call>\s*<function=lookup_deal>\s*<parameter=deal_id>[^<>]*</parameter>\s*</function>\s*</tool_call>\s*", raw)
        valid = bool(wrapper and len(calls)==1 and not output.get("parse_errors") and
                     calls[0]["name"] == "lookup_deal" and set(calls[0]["arguments"]) == {"deal_id"} and
                     isinstance(calls[0]["arguments"]["deal_id"], str))
        success = valid and calls[0] == target
    else:
        success = raw.strip() == target
    # Operational loop proxy: four consecutive copies of any four-word window.
    words = raw.split()
    loop = any(words[i:i+4]*4 == words[i:i+16] for i in range(len(words)-15))
    return {"success": bool(success and output.get("finish") == "stop"), "schema_valid": valid,
            "loop": loop, "exhausted": output.get("finish") == "length"}
