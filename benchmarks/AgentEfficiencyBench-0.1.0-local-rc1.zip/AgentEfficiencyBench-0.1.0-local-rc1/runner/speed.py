"""Standalone extraction of the typed route from runner/speed.py."""
import re


def route(task):
    if task.get("operation") != "stable_unique_ids":
        return None
    ids = task.get("ids")
    if not isinstance(ids,list) or not 1 <= len(ids) <= 512:
        return None
    if not all(isinstance(item,str) and re.fullmatch(r"[A-Z][0-9]{1,6}",item) for item in ids):
        return None
    return "\n".join(dict.fromkeys(ids))
