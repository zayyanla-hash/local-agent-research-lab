"""Local authorization boundary with optional, bounded advisory scoring."""
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from math import isfinite
from queue import Empty, Queue
from threading import Lock, Thread
from time import perf_counter
from typing import Literal
from uuid import uuid4

Score = Callable[[str, str], float]
ContextualScore = Callable[[str, str, str], float]
Status = Literal["disabled", "clear", "review", "abstain"]


@dataclass(frozen=True)
class Grant:
    action: str
    resource: str
    environment: str
    revision: str


@dataclass(frozen=True)
class ToolRequest(Grant):
    authorized_context: str = ""
    proposed_context: str = ""
    corroborating_context: str = ""


@dataclass(frozen=True)
class Advisory:
    status: Status
    stage: str
    reason: str
    score: float | None = None


@dataclass(frozen=True)
class InventoryAttestation:
    """Comparison produced by the trusted inventory adapter."""
    verified: bool
    reason: str


@dataclass(frozen=True)
class Decision:
    allowed: bool
    policy_reason: str
    advisory: Advisory
    escalation_attempted: bool
    wall_ms: float

    def audit_record(self) -> dict:
        # Explicit allowlist. No input fields, exceptions, score values, or
        # remotely supplied model identifiers appear in the persisted record.
        return {
            "event": uuid4().hex,
            "allowed": self.allowed,
            "policy": self.policy_reason,
            "advisory": self.advisory.status,
            "stage": self.advisory.stage,
            "reason": self.advisory.reason,
            "escalation_attempted": self.escalation_attempted,
            "wall_ms": self.wall_ms,
        }


class _Lane:
    """A timed-out call retains its lane until exit, bounding stranded workers."""
    def __init__(self):
        self.slot = Lock()

    def run(self, scorer: Callable[[], float], deadline: float, stage: str) -> Advisory:
        if deadline <= perf_counter():
            return Advisory("abstain", stage, "timeout")
        if not self.slot.acquire(blocking=False):
            return Advisory("abstain", stage, "busy")
        result = Queue(maxsize=1)

        def work():
            try:
                value = scorer()
                if type(value) in (int, float) and 0 <= value <= 2 and isfinite(value):
                    response = Advisory("clear", stage, "scored", float(value))
                else:
                    response = Advisory("abstain", stage, "malformed")
            except Exception:
                response = Advisory("abstain", stage, "unavailable")
            finally:
                self.slot.release()
            result.put_nowait(response)

        try:
            Thread(target=work, name="sentry-advisory", daemon=True).start()
        except RuntimeError:
            self.slot.release()
            return Advisory("abstain", stage, "unavailable")
        try:
            return result.get(timeout=max(0, deadline - perf_counter()))
        except Empty:
            return Advisory("abstain", stage, "timeout")


def _grant_fields(grant: Grant):
    return grant.action, grant.resource, grant.environment, grant.revision


class SentryGate:
    def __init__(self, grants: Iterable[Grant], scorer: Score | None = None, escalation: Score | None = None,
                 *, screening: Score | None = None, screen_clear_at: float = 0.25,
                 clear_at: float = 0.45, review_at: float = 0.5753889042346184,
                 timeout_ms: float = 50, assess_denied: bool = False,
                 inventory: InventoryAttestation | None = None, contextual_scorer: ContextualScore | None = None):
        if not 0 <= clear_at < review_at <= 2 or not 0 <= screen_clear_at <= 2:
            raise ValueError("Invalid score boundary.")
        if not isfinite(timeout_ms) or timeout_ms <= 0:
            raise ValueError("Timeout must be positive and finite.")
        trusted = [_grant_fields(grant) for grant in grants]
        if any(not all(type(x) is str and 0 < len(x) <= 160 for x in fields) for fields in trusted):
            raise ValueError("Invalid trusted grant.")
        if scorer is not None and contextual_scorer is not None:
            raise ValueError("Choose one contextual scorer.")
        self._grants = frozenset(trusted)
        self._contextual_scorer = contextual_scorer
        self._scorers = {"screen": screening, "context": contextual_scorer or scorer, "escalation": escalation}
        self._lanes = {name: _Lane() for name, fn in self._scorers.items() if fn is not None}
        self._screen_clear = screen_clear_at
        self._clear = clear_at
        self._review = review_at
        self._timeout = timeout_ms / 1000
        self._assess_denied = assess_denied
        self._inventory = inventory

    def _policy(self, request: ToolRequest) -> tuple[bool, str]:
        fields = _grant_fields(request)
        if not all(type(x) is str and 0 < len(x) <= 160 for x in fields):
            return False, "invalid_request"
        if self._inventory is not None and self._inventory.verified is not True:
            return False, "inventory_unverified"
        permitted = fields in self._grants
        return permitted, "in_scope" if permitted else "outside_grant"

    def _assess(self, lane: str, request: ToolRequest, deadline: float) -> Advisory:
        args = (request.authorized_context, request.proposed_context)
        if lane == "context" and self._contextual_scorer is not None:
            args += (request.corroborating_context,)
        scorer = self._scorers[lane]
        result = self._lanes[lane].run(lambda: scorer(*args), deadline, lane)
        if result.score is None:
            return result
        boundary = self._screen_clear if lane == "screen" else self._clear
        if result.score <= boundary:
            return Advisory("clear", lane, "below_clear_boundary", result.score)
        if lane != "screen" and result.score > self._review:
            return Advisory("review", lane, "above_review_boundary", result.score)
        return Advisory("abstain", lane, "uncertain", result.score)

    def _advice(self, request: ToolRequest, started: float) -> tuple[Advisory, bool]:
        texts = (request.authorized_context, request.proposed_context)
        if self._contextual_scorer is not None:
            texts += (request.corroborating_context,)
        if not all(type(text) is str and 0 < len(text) <= 4_096 for text in texts):
            return Advisory("abstain", "context", "invalid_context"), False
        deadline = started + self._timeout
        advisory = Advisory("abstain", "context", "unavailable")
        for stage in ("screen", "context", "escalation"):
            if stage in self._lanes and (stage != "escalation" or deadline > perf_counter()):
                advisory = self._assess(stage, request, deadline)
                if advisory.status != "abstain" or stage == "escalation":
                    return advisory, stage == "escalation"
        return advisory, False

    def evaluate(self, request: ToolRequest) -> Decision:
        started = perf_counter()
        allowed, reason = self._policy(request)
        if not allowed and (not self._assess_denied or reason == "invalid_request"):
            advisory, escalated = Advisory("disabled", "policy", "denied_at_policy"), False
        elif not self._lanes:
            advisory, escalated = Advisory("disabled", "policy", "policy_only"), False
        else:
            advisory, escalated = self._advice(request, started)
        return Decision(allowed, reason, advisory, escalated, (perf_counter() - started) * 1_000)
