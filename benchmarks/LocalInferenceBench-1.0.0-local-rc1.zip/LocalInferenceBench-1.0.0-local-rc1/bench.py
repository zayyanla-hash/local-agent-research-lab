#!/usr/bin/env python3
"""Grade archived or newly captured exact-copy LocalInferenceBench observations."""
import argparse
from collections import Counter, defaultdict
import json
from math import ceil, isfinite
from pathlib import Path
import re
from statistics import median

from workload import EXPECTED, SETTINGS

ROOT = Path(__file__).resolve().parent
HASH = re.compile(r"[0-9a-f]{64}")
CONTEXTS = {"process_cold": (512,), "resident_fresh": (512, 2048)}
INTS = ("prompt_tokens", "processed_prompt_tokens", "cached_prompt_tokens", "output_tokens",
        "engine_generated_tokens_including_eos", "peak_mlx_bytes", "peak_process_rss_bytes")
REQUIRED_METRICS = ("ttft_ms", "engine_prefill_tps", "generation_ms", "prep_ms", "request_wall_ms")
OPTIONAL_METRICS = ("first_text_ms", "post_first_decode_tps",
                    "host_first_engine_token_elapsed_ms", "host_completion_elapsed_ms")
STRINGS = ("variant", "finish", "raw_output", "prompt_token_ids_sha256", "output_token_ids_sha256")
FIELDS = {"repeat", "mode", "context", *INTS, *REQUIRED_METRICS, *OPTIONAL_METRICS, *STRINGS}


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON field {key!r}")
        result[key] = value
    return result


def reject_nonfinite(value):
    raise ValueError(f"Nonfinite JSON value {value}")


def nonnegative(value):
    return type(value) in {int, float} and isfinite(value) and value >= 0


def validate(row):
    if type(row) is not dict or row.keys() != FIELDS:
        raise ValueError("Observation fields differ from v1.0.0")
    if any(type(row[key]) is not str for key in STRINGS):
        raise ValueError("Expected string fields")
    if not row["variant"] or len(row["variant"]) > 160 or len(row["raw_output"]) > 16384:
        raise ValueError("Invalid arm name or output length")
    if row["finish"] not in {"stop", "length"}:
        raise ValueError("Unexpected terminal reason")
    if type(row["mode"]) is not str or row["mode"] not in CONTEXTS:
        raise ValueError("Unexpected measurement mode")
    if type(row["context"]) is not int or row["context"] not in CONTEXTS[row["mode"]]:
        raise ValueError("Unexpected requested context")
    if type(row["repeat"]) is not int or row["repeat"] < 0:
        raise ValueError("Repeat must be a nonnegative integer")
    if any(type(row[key]) is not int or row[key] < 0 for key in INTS):
        raise ValueError("Invalid token or memory count")
    if row["prompt_tokens"] != row["context"] or row["processed_prompt_tokens"] != row["context"] or row["cached_prompt_tokens"]:
        raise ValueError("Incorrect or reused prompt tokens")
    if any(not HASH.fullmatch(row[key]) for key in ("prompt_token_ids_sha256", "output_token_ids_sha256")):
        raise ValueError("Expected exact token hashes")
    if row["engine_generated_tokens_including_eos"] != row["output_tokens"] + int(row["finish"] == "stop"):
        raise ValueError("Output token counts disagree")
    if not 0 < row["engine_generated_tokens_including_eos"] <= SETTINGS["max_tokens"]:
        raise ValueError("Output token cap violated")
    if any(not nonnegative(row[key]) for key in REQUIRED_METRICS):
        raise ValueError("Required timing metric is invalid")
    if any(row[key] is not None and not nonnegative(row[key]) for key in OPTIONAL_METRICS):
        raise ValueError("An optional timing metric is invalid")
    if row["mode"] == "process_cold":
        first = row["host_first_engine_token_elapsed_ms"]
        completion = row["host_completion_elapsed_ms"]
        if first is None or completion is None or first > completion:
            raise ValueError("Cold process timing is a required ordered pair")
    elif any(row[key] is not None for key in OPTIONAL_METRICS[-2:]):
        raise ValueError("Resident observation includes cold process timing")
    return row


def read_observations(path):
    rows = []
    identities = set()
    with path.open(encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            if len(line) > 65536:
                raise ValueError(f"{path.name}:{number}: oversized row")
            row = validate(json.loads(line, object_pairs_hook=unique, parse_constant=reject_nonfinite))
            key = (row["variant"], row["mode"], row["context"], row["repeat"])
            if key in identities:
                raise ValueError(f"{path.name}:{number}: duplicate observation")
            identities.add(key)
            rows.append(row)
    if not rows:
        raise ValueError("No observations")
    return rows


def distribution(values):
    values = sorted(value for value in values if value is not None)
    if not values:
        return None
    return {"count": len(values), "median": median(values), "p95_nearest_rank": values[ceil(.95 * len(values)) - 1]}


def grade(rows):
    groups = defaultdict(list)
    identities = defaultdict(set)
    for row in rows:
        groups[row["variant"], row["mode"], row["context"]].append(row)
        identities[row["variant"], row["context"]].add(row["prompt_token_ids_sha256"])
    if any(len(hashes) != 1 for hashes in identities.values()):
        raise ValueError("A model arm and context must have one prompt identity across all modes")
    results = {}
    for (variant, mode, context), group in sorted(groups.items()):
        results.setdefault(variant, {})[f"{mode}_{context}"] = {
            "observations": len(group),
            "exact": sum(row["finish"] == "stop" and row["raw_output"].strip() == EXPECTED for row in group),
            "finish": dict(Counter(row["finish"] for row in group)),
            "total_output_tokens": sum(row["output_tokens"] for row in group),
            "prompt_token_ids_sha256": next(iter(identities[variant, context])),
            "metrics": {
                key: distribution(row[key] for row in group)
                for key in (*REQUIRED_METRICS, *OPTIONAL_METRICS, "peak_mlx_bytes", "peak_process_rss_bytes")
            },
        }
    return {"benchmark": "LocalInferenceBench", "version": "1.0.0", "variants": results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("replay", "grade"))
    parser.add_argument("--observations", type=Path)
    args = parser.parse_args()
    if args.command == "grade" and args.observations is None:
        parser.error("grade requires --observations")
    if args.command == "replay" and args.observations is not None:
        parser.error("replay uses the bundled synthetic observations")
    path = args.observations if args.command == "grade" else ROOT / "data" / "observations.jsonl"
    rows = read_observations(path)
    report = grade(rows)
    if args.command == "replay":
        report["source"] = "fictional validator smoke, no device capture"
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
