#!/usr/bin/env python3
"""Capture real local MLX runs for the fixed exact-copy workload."""
import argparse
from contextlib import contextmanager
import errno
from hashlib import file_digest
from importlib.metadata import version
import json
import os
from pathlib import Path
import platform
from queue import Empty, Queue
import resource
import socket
import subprocess
import sys
from threading import Thread
from time import perf_counter

from bench import ROOT, validate
from workload import SETTINGS, prepare_prompt, token_hash


def require_offline():
    with socket.socket() as sock:
        if sock.connect_ex(("127.0.0.1", 9)) not in {errno.EPERM, errno.EACCES}:
            raise RuntimeError("Run capture in a macOS sandbox with network denied")


def emit(row):
    print(json.dumps(row, allow_nan=False), flush=True)


def worker(model_path):
    import mlx.core as mx
    from mlx_lm import load, stream_generate
    from mlx_lm.models.cache import make_prompt_cache
    from mlx_lm.sample_utils import make_sampler

    model, tokenizer = load(str(model_path), tokenizer_config={
        "trust_remote_code": False, "local_files_only": True,
    })
    emit({"ready": True, "mlx": version("mlx"), "mlx-lm": version("mlx-lm")})
    for line in sys.stdin:
        request = json.loads(line)
        context = request["context"]
        prep_started = perf_counter()
        tokens = prepare_prompt(tokenizer, context)
        prep_ms = (perf_counter() - prep_started) * 1000
        cache = make_prompt_cache(model)
        mx.random.seed(SETTINGS["seed"])
        mx.reset_peak_memory()
        start = perf_counter()
        first = first_text = last = None
        parts, ids = [], []
        result = None
        for result in stream_generate(
            model, tokenizer, tokens, max_tokens=SETTINGS["max_tokens"], prompt_cache=cache,
            sampler=make_sampler(temp=SETTINGS["temperature"]),
            prefill_step_size=SETTINGS["prefill_step_size"],
        ):
            last = perf_counter()
            if first is None:
                first = last
            if first_text is None and result.text:
                first_text = last
            ids.append(int(result.token))
            parts.append(result.text)
        end = perf_counter()
        if result is None or len(ids) != result.generation_tokens or result.prompt_tokens != len(tokens):
            raise ValueError("Engine token counts differ from the observed stream")
        eos = int(result.finish_reason == "stop")
        emit({
            "finish": result.finish_reason, "raw_output": "".join(parts),
            "prompt_tokens": len(tokens), "processed_prompt_tokens": result.prompt_tokens, "cached_prompt_tokens": 0,
            "prompt_token_ids_sha256": token_hash(tokens),
            "output_token_ids_sha256": token_hash(ids[:-1] if eos else ids),
            "output_tokens": len(ids) - eos, "engine_generated_tokens_including_eos": len(ids),
            "ttft_ms": (first - start) * 1000,
            "first_text_ms": (first_text - start) * 1000 if first_text is not None else None,
            "engine_prefill_tps": result.prompt_tps,
            "post_first_decode_tps": (len(ids) - 1) / (last - first) if len(ids) > 1 else None,
            "generation_ms": (end - start) * 1000, "prep_ms": prep_ms,
            "peak_mlx_bytes": mx.get_peak_memory(),
            "peak_process_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        })


def receive(stream, timeout):
    try:
        line = stream.get(timeout=timeout)
    except Empty as error:
        raise TimeoutError("Local worker response timed out") from error
    if line is None:
        raise RuntimeError("Local worker exited before completing its reply")
    return json.loads(line)


@contextmanager
def start_worker(model, timeout):
    env = {**os.environ, "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
           "HF_HUB_DISABLE_TELEMETRY": "1", "PYTHONDONTWRITEBYTECODE": "1"}
    started = perf_counter()
    with subprocess.Popen(
        [sys.executable, str(ROOT / "capture.py"), str(model), "--worker"],
        env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True,
    ) as process:
        replies = Queue()

        def read_replies():
            for line in process.stdout:
                replies.put(line)
            replies.put(None)

        Thread(target=read_replies, daemon=True).start()
        try:
            ready = receive(replies, timeout)
            if ready.pop("ready", None) is not True:
                raise ValueError("Local worker supplied invalid startup metadata")
            yield process, replies, started, ready
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()


def measure(process, replies, started, arm, mode, repeat, context, timeout):
    request_start = perf_counter()
    process.stdin.write(json.dumps({"context": context}) + "\n")
    process.stdin.flush()
    row = receive(replies, timeout)
    completed = perf_counter()
    cold = mode == "process_cold"
    return validate({
        **row, "variant": arm, "repeat": repeat, "mode": mode, "context": context,
        "request_wall_ms": (completed - request_start) * 1000,
        "host_first_engine_token_elapsed_ms": (
            (request_start - started) * 1000 + row["prep_ms"] + row["ttft_ms"] if cold else None
        ),
        "host_completion_elapsed_ms": (completed - started) * 1000 if cold else None,
    })


def file_hashes(model_path):
    files = {}
    for path in sorted(model_path.iterdir()):
        if path.is_file() and path.suffix in {".safetensors", ".json", ".jinja", ".txt"}:
            with path.open("rb") as source:
                files[path.name] = file_digest(source, "sha256").hexdigest()
    if not any(name.endswith(".safetensors") for name in files):
        raise ValueError("Expected local safetensors checkpoint files")
    return files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path, help="An existing local MLX model directory")
    parser.add_argument("--variant", default="local-model")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--timeout", type=float, default=60)
    parser.add_argument("--smoke", action="store_true", help="Run one cold and one resident 512-token request")
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    require_offline()
    model = args.model.resolve(strict=True)
    if not model.is_dir():
        parser.error("MODEL must be a local directory")
    if args.worker:
        worker(model)
        return
    if args.output is None or not 0 < args.timeout <= 600:
        parser.error("capture requires --output and a timeout within (0, 600]")
    output = args.output
    receipt = output.with_name(output.name + ".receipt.json")
    if output.exists() or receipt.exists():
        parser.error("Choose a fresh output path for the capture")
    identities = file_hashes(model)
    rows = []
    cold_repeats = 1 if args.smoke else 2
    for repeat in range(cold_repeats):
        with start_worker(model, args.timeout) as (process, replies, started, runtime):
            rows.append(measure(process, replies, started, args.variant, "process_cold", repeat, 512, args.timeout))
    with start_worker(model, args.timeout) as (process, replies, started, runtime):
        # A warm-up call gets a fresh cache. Its response is excluded from the report.
        measure(process, replies, started, args.variant, "resident_fresh", 0, 512, args.timeout)
        for repeat in range(1 if args.smoke else 3):
            contexts = (512,) if args.smoke else (512, 2048) if repeat % 2 == 0 else (2048, 512)
            for context in contexts:
                rows.append(measure(process, replies, started, args.variant, "resident_fresh", repeat, context, args.timeout))
    with output.open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, allow_nan=False) + "\n")
    with output.open("rb") as stream:
        digest = file_digest(stream, "sha256").hexdigest()
    with receipt.open("x", encoding="utf-8") as stream:
        json.dump({
            "version": "1.0.0", "variant": args.variant, "platform": platform.platform(),
            "python": platform.python_version(), "runtime": runtime, "profile": "smoke" if args.smoke else "original",
            "network_denied": True, "checkpoint_sha256": identities,
            "observations": len(rows), "observations_sha256": digest,
        }, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
