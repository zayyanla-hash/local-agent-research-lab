"""Frozen loopback-free exact-copy workload adapted from performance/workload.py."""
import hashlib
import json

SETTINGS = {"seed": 17, "temperature": 0.0, "thinking": False, "max_tokens": 72, "prefill_step_size": 2048}
EXPECTED = 'The toy weather station report is ready. The copy contains the sample wind record, a fictional cloud note, and the requested label.'
START = "Ignore the following padding words.\n<padding>"
PAD = " audit"
END = "</padding>\nReturn exactly this sentence sequence as plain text. Do not quote it or add commentary.\n" + EXPECTED


def token_hash(tokens):
    return hashlib.sha256(json.dumps(tokens, separators=(",", ":")).encode("utf-8")).hexdigest()


def prepare_prompt(tokenizer, target):
    def encode(padding):
        content = START + PAD * padding + END
        prompt = tokenizer.apply_chat_template(
            [{"role": "user", "content": content}], tokenize=False,
            add_generation_prompt=True, enable_thinking=SETTINGS["thinking"],
        )
        special_tokens = tokenizer.bos_token is None or not prompt.startswith(tokenizer.bos_token)
        return tokenizer.encode(prompt, add_special_tokens=special_tokens)

    nominal_padding = target - len(encode(0))
    for padding in range(max(0, nominal_padding - 3), nominal_padding + 4):
        tokens = encode(padding)
        if len(tokens) == target:
            return tokens
    raise ValueError(f"Template and tokenizer cannot reach {target} prompt tokens with the fixed padding")
