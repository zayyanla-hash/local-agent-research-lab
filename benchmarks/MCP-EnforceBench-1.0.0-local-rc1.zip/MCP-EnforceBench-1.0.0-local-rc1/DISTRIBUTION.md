# Licensing and attribution

Original software, schemas, and runner configuration are copyright 2026 Zayyan Latif.
They are licensed under the [Apache License 2.0](LICENSE).

The original fictional smoke data below are copyright 2026 Zayyan Latif and licensed under
[Creative Commons Attribution 4.0 International](licenses/CC-BY-4.0.txt). Attribute the data
as "MCP-EnforceBench-1.0.0 synthetic smoke fixtures by Zayyan Latif, CC BY 4.0" and indicate changes.

- `data/scope-inputs.jsonl`
- `data/scope-answers.jsonl`
- `data/grounding-inputs.jsonl`
- `data/grounding-answers.jsonl`

Obtained separately, upstream data retain publisher terms and attribution requirements.
The bundled smoke data have visible expected behavior. Hardware scores, matched model results,
and security assurance require separate evidence.
