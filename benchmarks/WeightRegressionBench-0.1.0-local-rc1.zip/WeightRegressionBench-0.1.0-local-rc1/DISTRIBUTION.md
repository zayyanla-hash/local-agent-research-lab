# Licensing and attribution

Original software, schemas, and runner configuration are copyright 2026 Zayyan Latif.
They are licensed under the [Apache License 2.0](LICENSE).

The original fictional smoke data below are copyright 2026 Zayyan Latif and licensed under
[Creative Commons Attribution 4.0 International](licenses/CC-BY-4.0.txt). Attribute the data
as "WeightRegressionBench-0.1.0 synthetic smoke fixtures by Zayyan Latif, CC BY 4.0" and indicate changes.

- `fixtures/synthetic.jsonl`
- `fixtures/synthetic-pass.jsonl`
- `fixtures/synthetic-fail.jsonl`

The BFCL modules under `bfcl_eval/` retain the upstream Gorilla
[Apache License 2.0 and its notices](licenses/Apache-2.0.txt).
The local `model_config.py` shim is marked as modified for offline use.
[Pinned Gorilla source](https://github.com/ShishirPatil/gorilla/tree/f7cf7359b7ac615a0b294831c5ba2bc95ee4a000/berkeley-function-call-leaderboard).

Obtained separately, upstream data retain publisher terms and attribution requirements.
The bundled smoke data have visible expected behavior. Hardware scores, matched model results,
and security assurance require separate evidence.
