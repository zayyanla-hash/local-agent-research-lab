"""Score static call records and compare matched intervention arms."""
import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from bfcl_eval.constants.enums import Language
from bfcl_eval.eval_checker.ast_eval.ast_checker import ast_checker
from regression import gate
from runner.smoke import digest, file_hash

FIXTURES = Path(__file__).resolve().parent / "fixtures"
VERSION = "0.1.0"
TRACKS = ("bfcl", "synthetic")


def records(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def case_path(track, path):
    if path is None and track == "bfcl":
        raise ValueError("bfcl requires --cases with caller-supplied normalized rows")
    return path if path is not None else FIXTURES / "synthetic.jsonl"


def grade(case, observation):
    calls = observation["tool_calls"]
    errors = observation["parse_errors"]
    if not isinstance(calls, list) or not isinstance(errors, list) or any(not isinstance(e, str) for e in errors):
        raise ValueError("expected a list of calls and a list of parse error strings")
    if any(not isinstance(call, dict) or len(call) != 1 or
           any(not isinstance(value, dict) for value in call.values()) for call in calls):
        raise ValueError("each call must map exactly one function name to its arguments")
    if errors or len(calls) != 1:
        return {"valid": False, "error_type": "ast_decoder:decoder_failed" if errors or not calls else "call_count"}
    return ast_checker(case["function"], calls, case["ground_truth"], Language.PYTHON,
                       "simple_python", "local-qwen")


def normalized(track, observation_path, meta_path, input_path=None):
    path = case_path(track, input_path)
    cases = records(path)
    if not cases or len({case["id"] for case in cases}) != len(cases):
        raise ValueError("Expected unique case IDs and at least one case")
    source = records(observation_path)
    meta = gate.json_read(meta_path)
    observations = {row["case"]: row for row in source}
    if len(source) != len(observations) or set(observations) != {case["id"] for case in cases}:
        raise ValueError("observations must cover every case exactly once")
    rows = []
    for case in cases:
        observation = observations[case["id"]]
        result = grade(case, observation)
        passed = result["valid"]
        metrics = {"tool_calls": len(observation["tool_calls"])}
        metrics.update({name: observation[field] for name, field in
                        (("context_tokens", "prompt_tokens"), ("generated_tokens", "output_tokens"))
                        if field in observation})
        rows.append({"case": case["id"], "case_sha256": digest(case), "category": track,
                     "cluster": case["id"], "condition": "static_single_call", "repeat": 0,
                     "success": passed, "checks": {"static_ast": passed},
                     "failure": result.get("error_type") if not passed else None,
                     "behavior_sha256": digest(observation["tool_calls"]) if passed else None, "metrics": metrics})
    return gate.validate({"version": 1, "suite": "weight_regression_bench_v0_1", "split": track,
                          "dataset_sha256": file_hash(path),
                          "protocol": meta["protocol"], "identity": meta["identity"],
                          "sources": {"observations": file_hash(observation_path), "metadata": file_hash(meta_path),
                                      "ast_checker": file_hash(Path(__file__).resolve().parent /
                                                               "bfcl_eval/eval_checker/ast_eval/ast_checker.py")},
                          "reproduce": f"python3 bench.py score {track} OBSERVATIONS.jsonl META.json ARCHIVE.json --cases CASES.jsonl",
                          "rows": rows})


def sample():
    with TemporaryDirectory(prefix="weight-regression-") as folder:
        output = Path(folder)
        for arm in ("synthetic-pass", "synthetic-fail"):
            archive = normalized("synthetic", FIXTURES / f"{arm}.jsonl", FIXTURES / "synthetic.json")
            archive["identity"]["id"] = arm
            gate.json_write(output / f"{arm}.json", archive)
        baseline = output / "synthetic-pass.json"
        frozen = output / "frozen.json"
        gate.json_write(frozen, gate.freeze(baseline, FIXTURES / "profile.json"))
        same = gate.compare(baseline, baseline, frozen)
        broken = gate.compare(baseline, output / "synthetic-fail.json", frozen)
        return {"identical_control": same["decision"], "deliberate_regression": broken["decision"],
                "task_success": broken["task_success"]}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--version", action="version", version=VERSION)
    sub = cli.add_subparsers(dest="mode", required=True)
    sub.add_parser("sample", help="score the fictional gate controls")
    inputs = sub.add_parser("cases", help="export model-visible inputs")
    inputs.add_argument("track", choices=TRACKS)
    score = sub.add_parser("score", help="normalize an arm for the regression gate")
    score.add_argument("track", choices=TRACKS)
    for name in ("observations", "metadata", "output"):
        score.add_argument(name, type=Path)
    for command in (inputs, score):
        command.add_argument("--cases", type=Path)
    args = cli.parse_args()
    try:
        if args.mode == "score":
            gate.json_write(args.output, normalized(args.track, args.observations, args.metadata, args.cases))
        elif args.mode == "sample":
            print(json.dumps(sample(), indent=2, sort_keys=True, allow_nan=False))
        else:
            cases = [{key: value for key, value in case.items() if key != "ground_truth"} for case in records(case_path(args.track, args.cases))]
            print(json.dumps(cases, indent=2, sort_keys=True, allow_nan=False))
    except (KeyError, TypeError, ValueError, OSError) as exc:
        cli.error(str(exc))


if __name__ == "__main__":
    main()
