# Modified for local review: replace upstream provider settings with an offline parser shim.
"""Minimal BFCL parser identity, with no live model provider imports."""
from types import SimpleNamespace

MODEL_CONFIG_MAPPING = {"local-qwen": SimpleNamespace(underscore_to_dot=False)}
