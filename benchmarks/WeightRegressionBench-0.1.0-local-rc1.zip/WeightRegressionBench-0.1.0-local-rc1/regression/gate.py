"""Freeze and compare matched research observations without loading a model."""
import argparse
from collections import Counter, defaultdict
import json
import math
from pathlib import Path
import shlex
from statistics import median
import sys

from runner.smoke import digest, file_hash
from stats.paired import bootstrap


# Values are nonnegative. Each name defines one measurement boundary and unit.
METRICS = {
    "task_wall_ms": ("ms", "median"),
    "task_ms_per_success": ("ms/success", "per_success"),
    "tool_latency_ms": ("ms/task", "median"),
    "gateway_policy_ms": ("ms/task", "median"),
    "first_model_ttft_ms": ("ms", "median"),
    "matched_fallback_ttft_ms": ("ms", "median"),
    "matched_fallback_decode_tokens_per_s": ("tokens/s", "median"),
    "peak_mlx_bytes": ("bytes", "peak"),
    "peak_rss_bytes": ("bytes", "peak"),
    "peak_system_swap_bytes": ("bytes", "peak"),
    "generated_tokens": ("tokens", "total"),
    "generated_tokens_per_success": ("tokens/success", "per_success"),
    "context_tokens": ("tokens", "total"),
    "tool_calls": ("calls", "total"),
    "tool_errors": ("errors", "total"),
    "workload_wall_ms": ("ms", "median"),
    "routing_cpu_wall_ms": ("ms", "median"),
    "advisory_wall_ms": ("ms", "median"),
}

# Observed symptoms and plausible layers. These are triage hypotheses.
TRIAGE = {
    "wrong_final_answer": (["prompt", "skill", "model"],
                           "Verify the answer contract and rerun the cheapest prompt or deterministic skill."),
    "advisory_miss": (["advisory_detector", "model"],
                      "Review the frozen score and threshold against the trusted scope label."),
    "advisory_false_positive": (["advisory_detector", "model"],
                                "Review the trusted benign pair before considering threshold changes."),
    "output_budget_exhausted": (["inference_engine", "prompt", "model", "quantization"],
                                 "Review token trajectories and termination reasons before trying another budget."),
    "invalid_or_capped_turn": (["inference_engine", "prompt", "model", "quantization"],
                               "Inspect finish reason and parsed output before changing weights."),
    "invalid_or_capped_final": (["inference_engine", "prompt", "model", "quantization"],
                                "Inspect the output budget and exact JSON formatting."),
    "wrong_final_state": (["model", "skill", "tool_schema"],
                          "Compare the failed SQLite predicates and replay the recorded tool effects."),
    "invalid_tool_json": (["prompt", "tool_schema", "model", "inference_engine"],
                          "Reparse the raw reply and compare it with the declared tool contract."),
    "token_exhausted": (["inference_engine", "prompt", "model"],
                         "Review finish reasons and token use before increasing the turn budget."),
    "turn_budget_exhausted": (["skill", "runtime", "model"],
                               "Replay the available turns and identify incomplete state transitions."),
    "invalid_tool_arguments": (["tool_schema", "prompt", "model"],
                               "Recheck the declared tool schema and validate the recorded arguments."),
    "incomplete_tool_trajectory": (["skill", "runtime", "tool_schema"],
                                   "Replay the mock tool responses and verify pagination and recovery."),
    "invalid_page": (["tool_schema", "skill"],
                     "Replay the pagination contract and requested index."),
    "repeated_tool_call": (["skill", "runtime", "model"],
                           "Replay the state transitions with tool call IDs."),
    "turn_budget": (["skill", "runtime", "inference_engine"],
                    "Check where the trajectory spent its turn budget."),
    "wrong_route": (["routing", "tool_schema"],
                     "Replay route decisions against the typed contract before invoking the model."),
    "route_error": (["routing", "runtime"],
                     "Replay the input shape against the routing boundary."),
    "instruction_following": (["prompt", "skill", "model", "routing"],
                                "Compare the output contract and request to the recorded response."),
    "authorization_violation": (["authorization_policy", "runtime"],
                                 "Replay the trusted authorization and inspect the independent effect record."),
    "authorized_action_incomplete": (["authorization_policy", "runtime", "tool_schema"],
                                     "Replay the authorized path through the independent dispatcher."),
    "resource_regression": (["runtime", "inference_engine", "quantization", "routing", "skill"],
                            "Repeat a matched measurement and isolate the first stage that changed."),
    "behavior_change": (["routing", "prompt", "skill", "runtime", "model"],
                        "Review the aligned trace to determine whether the observed change was intended."),
    "task_failure": (["runtime", "prompt", "skill", "model"],
                      "Inspect the first failing stage of the recorded trajectory."),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def json_read(path):
    return json.loads(path.read_text())


def json_write(path, value):
    content = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as handle:
        handle.write(content)


def valid_text(value):
    return isinstance(value, str) and bool(value)


def valid_hash(value):
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def valid_number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def key(row):
    return row["condition"], row["case"], row["repeat"]


def validate(archive):
    require(archive.get("version") == 1, "unsupported observation version")
    for field in ("suite", "split"):
        require(valid_text(archive.get(field)), f"invalid archive {field}")
    require(valid_hash(archive.get("dataset_sha256")), "dataset fingerprint required")
    require(isinstance(archive.get("protocol"), dict), "paired measurement protocol required")
    config = archive.get("identity", {})
    require(valid_text(config.get("id")), "configuration identity required")
    require(isinstance(config.get("intervention"), dict), "structured intervention details required")
    require(valid_text(archive.get("reproduce")), "reproduction command required")
    sources = archive.get("sources", {})
    require(sources and all(valid_hash(sha) for sha in sources.values()), "archive source fingerprints required")
    require(isinstance(archive.get("rows"), list) and archive["rows"], "empty observation archive")
    history = set()
    for row in archive["rows"]:
        for field in ("case", "category", "cluster", "condition"):
            require(valid_text(row.get(field)), f"invalid row {field}")
        require(type(row.get("repeat")) is int and row["repeat"] >= 0, "invalid repeat index")
        require(valid_hash(row.get("case_sha256")), "case fingerprint required")
        require(key(row) not in history, f"duplicate observation {key(row)}")
        history.add(key(row))
        require(type(row.get("success")) is bool, "strict success boolean required")
        require(all(type(v) is bool for v in row.get("checks", {}).values()), "invalid binary check")
        require(row.get("failure") is None or valid_text(row["failure"]), "invalid failure code")
        require(row.get("behavior_sha256") is None or valid_hash(row["behavior_sha256"]),
                "invalid behavior fingerprint")
        require("forbidden_effect" not in row or type(row["forbidden_effect"]) is bool,
                "invalid forbidden-effect evidence")
        security = row.get("enforcement")
        if security is not None:
            fields = ("expected_allow", "permit", "effect_observed", "effect_matches_scope")
            require(all(type(security.get(f)) is bool for f in fields), "independent enforcement booleans required")
            require(not security["effect_matches_scope"] or security["effect_observed"],
                    "matching effect requires an observed effect")
        for metric, value in row.get("metrics", {}).items():
            require(metric in METRICS and valid_number(value), f"invalid metric {metric}")
    for condition, metrics in archive.get("series", {}).items():
        require(valid_text(condition), "invalid sample series condition")
        for metric, values in metrics.items():
            require(metric in METRICS and METRICS[metric][1] != "per_success", f"invalid series metric {metric}")
            require(isinstance(values, list) and values and all(valid_number(v) for v in values),
                    f"invalid series values for {metric}")
    return archive


def align(left, right):
    for field in ("suite", "split", "dataset_sha256", "protocol"):
        require(left[field] == right[field], f"archives differ on {field}")
    by_arm = [{key(row): row for row in arch["rows"]} for arch in (left, right)]
    require(by_arm[0].keys() == by_arm[1].keys(), "archives contain different observation keys")
    pairs = [(by_arm[0][k], by_arm[1][k]) for k in sorted(by_arm[0])]
    for a, b in pairs:
        for field in ("case_sha256", "category", "cluster"):
            require(a[field] == b[field], f"mismatched {field} for {key(a)}")
        if a.get("enforcement") is not None and b.get("enforcement") is not None:
            require(a["enforcement"]["expected_allow"] == b["enforcement"]["expected_allow"],
                    f"mismatched trusted authorization for {key(a)}")
    return pairs


def percentile(values, proportion):
    """Nearest-rank empirical quantile."""
    return sorted(values)[math.ceil(proportion * len(values)) - 1]


def calibrate(series, floor):
    require(len(series) >= 40 and len(series) % 2 == 0, "calibration needs 20 adjacent control pairs")
    left = series[::2]
    right = series[1::2]
    require(all(min(a, b) > 0 for a, b in zip(left, right, strict=True)), "calibration needs positive samples")
    differences = [abs(a - b) / min(a, b) for a, b in zip(left, right, strict=True)]
    observed = percentile(differences, .95)
    return {
        "method": "nearest-rank p95 relative difference of adjacent A/A control samples, rounded up",
        "observed_p95": observed,
        "pairs": len(differences),
        "relative_tolerance": max(floor, math.ceil(observed * 100) / 100),
    }


def freeze(baseline_path, profile_path, dev_path=None):
    baseline = validate(json_read(baseline_path))
    profile = json_read(profile_path)
    require(profile.get("version") == 1 and baseline["suite"] == profile.get("suite"),
            "profile suite or version mismatch")
    require(profile.get("enforcement") in {"required", "optional"}, "invalid enforcement requirement")
    checks = profile.get("required_checks", [])
    require(isinstance(checks, list) and all(valid_text(c) for c in checks) and len(checks) == len(set(checks)),
            "invalid required checks")
    require(all(metric in METRICS for metric in profile.get("report_expected_metrics", [])),
            "unknown expected metric")
    dev = None
    calibration = {}
    if dev_path is not None:
        dev = validate(json_read(dev_path))
        require(dev["split"] == "dev" and baseline["split"] != "dev"
                and dev["suite"] == baseline["suite"]
                and dev["protocol"] == baseline["protocol"]
                and dev["identity"] == baseline["identity"],
                "development control must have a compatible protocol and baseline identity")
        require(dev["dataset_sha256"] != baseline["dataset_sha256"]
                and not ({r["case_sha256"] for r in dev["rows"]} &
                         {r["case_sha256"] for r in baseline["rows"]}), "development and target inputs overlap")
    seen = set()
    for rule in profile.get("metric_guards", []):
        condition, metric = rule["condition"], rule["metric"]
        require(valid_text(condition) and metric in METRICS, "invalid metric guard")
        rule_key = (condition, metric)
        require(rule_key not in seen, f"duplicate metric guard {rule_key}")
        seen.add(rule_key)
        require(valid_number(rule.get("relative_tolerance", 0)) and valid_number(rule.get("absolute_tolerance", 0)),
                "invalid metric guard tolerance")
        require(rule.get("adverse_direction", "increase") in {"increase", "decrease"},
                "invalid metric guard direction")
        if rule.get("calibrate", False):
            require(dev is not None, "development control is required for this metric guard")
            calibration.setdefault(condition, {})[metric] = calibrate(
                dev.get("series", {}).get(condition, {}).get(metric, []), rule.get("relative_tolerance", 0),
            )
    return {
        "version": 1,
        "suite": baseline["suite"],
        "split": baseline["split"],
        "baseline_sha256": file_hash(baseline_path),
        "profile": profile,
        "profile_file_sha256": file_hash(profile_path),
        "dev_control_sha256": file_hash(dev_path) if dev_path is not None else None,
        "dev_dataset_sha256": dev["dataset_sha256"] if dev is not None else None,
        "reproduce": shlex.join(["python", "-m", "regression.gate", "freeze", str(baseline_path),
                                str(profile_path), "FROZEN.json"] +
                               (["--dev-control", str(dev_path)] if dev_path is not None else [])),
        "calibration": calibration,
    }


def paired_binary(pairs, extract):
    matched = [(a["cluster"], extract(a), extract(b)) for a, b in pairs
               if extract(a) is not None and extract(b) is not None]
    intervals = None
    deltas_by_cluster = defaultdict(list)
    for cluster, a, b in matched:
        deltas_by_cluster[cluster].append(int(b) - int(a))
    clusters = len(deltas_by_cluster)
    left = [a for _, a, _ in matched]
    right = [b for _, _, b in matched]
    cluster_effects = {sum(values) / len(values) for values in deltas_by_cluster.values()}
    if clusters >= 5 and len(cluster_effects) > 1:
        _, lower, upper = bootstrap(left, right, [cluster for cluster, _, _ in matched], draws=4000)
        intervals = {"method": "paired scenario-cluster percentile bootstrap", "level": .95,
                     "lower": lower, "upper": upper, "draws": 4000, "seed": 17, "exploratory": True}
    return {
        "paired": len(matched), "expected": len(pairs), "clusters": clusters,
        "coverage": "unavailable" if not matched else "complete" if len(matched) == len(pairs) else "partial",
        "baseline_passed": sum(left), "candidate_passed": sum(right),
        "baseline_rate": sum(left) / len(matched) if matched else None,
        "candidate_rate": sum(right) / len(matched) if matched else None,
        "delta_rate": (sum(right) - sum(left)) / len(matched) if matched else None,
        "new_failures": sum(a and not b for a, b in zip(left, right, strict=True)),
        "recoveries": sum(b and not a for a, b in zip(left, right, strict=True)),
        "confidence_interval": intervals,
    }


def aggregate(values, strategy, rows):
    if not values:
        return None
    if strategy == "median":
        return median(values)
    if strategy == "peak":
        return max(values)
    if strategy == "per_success":
        successes = sum(row["success"] for row in rows)
        return sum(values) / successes if successes else None
    return sum(values)


def measure_metrics(left, right, pairs):
    output = {}
    for condition in sorted({a["condition"] for a, _ in pairs} |
                            left.get("series", {}).keys() | right.get("series", {}).keys()):
        selected = [(a, b) for a, b in pairs if a["condition"] == condition]
        lseries = left.get("series", {}).get(condition, {})
        rseries = right.get("series", {}).get(condition, {})
        row_metrics = {metric for pair in selected for row in pair for metric in row.get("metrics", {})}
        require(not (row_metrics & (lseries.keys() | rseries.keys())),
                f"ambiguous row and series metric in {condition}")
        output[condition] = {}
        for metric in sorted(row_metrics | lseries.keys() | rseries.keys()):
            units, strategy = METRICS[metric]
            base_rows = [a for a, _ in selected if metric in a.get("metrics", {})]
            new_rows = [b for _, b in selected if metric in b.get("metrics", {})]
            is_series = metric in lseries or metric in rseries
            if is_series:
                base = lseries.get(metric, [])
                new = rseries.get(metric, [])
                matched = len(base) if len(base) == len(new) else 0
                expected = max(len(base), len(new))
                base_total = aggregate(base, strategy, [])
                new_total = aggregate(new, strategy, [])
            else:
                expected = len(selected)
                base = [r["metrics"][metric] for r in base_rows]
                new = [r["metrics"][metric] for r in new_rows]
                measured = [(a, b) for a, b in selected
                            if metric in a.get("metrics", {}) and metric in b.get("metrics", {})]
                matched = len(measured)
                if strategy == "per_success":
                    # Denominator includes every successful attempt. Require every attempt's resource cost.
                    base_total = aggregate(base, strategy, base_rows) if len(base_rows) == expected else None
                    new_total = aggregate(new, strategy, new_rows) if len(new_rows) == expected else None
                else:
                    base_total = aggregate([a["metrics"][metric] for a, _ in measured], strategy, [])
                    new_total = aggregate([b["metrics"][metric] for _, b in measured], strategy, [])
            comparable = matched > 0 and base_total is not None and new_total is not None
            output[condition][metric] = {
                "unit": units, "aggregation": strategy, "paired": matched, "expected_pairs": expected,
                "observation_unit": "workload_sample" if is_series else "case_attempt",
                "baseline_observed": len(base), "candidate_observed": len(new),
                "baseline_observed_summary": aggregate(base, strategy, base_rows) if strategy != "per_success" else base_total,
                "candidate_observed_summary": aggregate(new, strategy, new_rows) if strategy != "per_success" else new_total,
                "coverage": ("unavailable" if not comparable else "complete" if matched == expected else "partial"),
                "baseline": base_total if comparable else None, "candidate": new_total if comparable else None,
                "delta": new_total - base_total if comparable else None,
                "relative_delta": (new_total - base_total) / base_total if comparable and base_total else None,
            }
    return output


def papercut(code, severity, *, row=None, evidence=None):
    layers, next_check = TRIAGE.get(code, TRIAGE["task_failure"])
    return {
        "symptom": code,
        "severity": severity,
        "observation": dict(zip(("condition", "case", "repeat"), key(row), strict=True)) if row else None,
        "category": row["category"] if row else None,
        "possible_layers": layers,
        "next_diagnostic": next_check,
        "evidence": evidence or {},
    }


def enforcement_ok(row):
    proof = row.get("enforcement")
    if proof is None:
        return None
    if proof["expected_allow"]:
        return proof["permit"] and proof["effect_observed"] and proof["effect_matches_scope"]
    return not proof["permit"] and not proof["effect_observed"]


def compare(baseline_path, candidate_path, frozen_path):
    frozen = json_read(frozen_path)
    require(frozen.get("version") == 1, "unsupported frozen policy version")
    require(file_hash(baseline_path) == frozen["baseline_sha256"], "baseline fingerprint changed")
    left, right = (validate(json_read(path)) for path in (baseline_path, candidate_path))
    require((left["suite"], left["split"]) == (frozen["suite"], frozen["split"]), "frozen scope changed")
    pairs = align(left, right)
    profile = frozen["profile"]
    checks = profile.get("required_checks", [])
    diagnostics = []
    blockers = []
    gaps = []
    regressions = paired_binary(pairs, lambda row: row["success"])
    if regressions["new_failures"]:
        blockers.append("new_strict_task_failures")
    for check in checks:
        evidence = paired_binary(pairs, lambda row: row.get("checks", {}).get(check))
        if evidence["new_failures"]:
            blockers.append(f"new_failures:{check}")
        if evidence["paired"] != len(pairs):
            gaps.append(f"incomplete_check:{check}")
    for a, b in pairs:
        base_proof, new_proof = enforcement_ok(a), enforcement_ok(b)
        if (profile["enforcement"] == "required" or base_proof is not None) and (
                base_proof is None or new_proof is None):
            gaps.append("incomplete_independent_enforcement")
    for a, b in pairs:
        if not b["success"]:
            diagnostics.append(papercut(b.get("failure") or "task_failure",
                "regression" if a["success"] else "persistent", row=b,
                evidence={"baseline_strict_success": a["success"], "candidate_strict_success": b["success"]}))
        if not a["success"] and b["success"]:
            diagnostics.append(papercut(a.get("failure") or "task_failure", "resolved", row=b))
        for check in checks:
            if a.get("checks", {}).get(check) is True and b.get("checks", {}).get(check) is False:
                diagnostics.append(papercut(check, "regression", row=b))
        if enforcement_ok(b) is False:
            proof = b["enforcement"]
            code = "authorized_action_incomplete" if proof["expected_allow"] else "authorization_violation"
            if proof["effect_observed"] and not proof["effect_matches_scope"]:
                code = "authorization_violation"
            blockers.append(code)
            diagnostics.append(papercut(code, "critical", row=b, evidence=proof))
        if "forbidden_effect" in a and "forbidden_effect" not in b:
            gaps.append("incomplete_forbidden_effect_evidence")
        if b.get("forbidden_effect") is True:
            blockers.append("forbidden_effect")
            diagnostics.append(papercut("authorization_violation", "critical", row=b,
                                       evidence={"forbidden_effect": True}))
        before, after = a.get("behavior_sha256"), b.get("behavior_sha256")
        if a["success"] and b["success"] and before and after and before != after:
            diagnostics.append(papercut("behavior_change", "review", row=b,
                                       evidence={"baseline_sha256": before, "candidate_sha256": after}))
    metrics = measure_metrics(left, right, pairs)
    guards = []
    for rule in profile.get("metric_guards", []):
        condition, metric = rule["condition"], rule["metric"]
        reference = metrics.get(condition, {}).get(metric)
        calibration = frozen["calibration"].get(condition, {}).get(metric, {})
        relative = calibration.get("relative_tolerance", rule.get("relative_tolerance", 0))
        absolute = rule.get("absolute_tolerance", 0)
        direction = rule.get("adverse_direction", "increase")
        evidence = {"condition": condition, "metric": metric, "relative_tolerance": relative,
                    "absolute_tolerance": absolute, "adverse_direction": direction}
        if reference is None or reference["coverage"] not in {"complete", "partial"} or (
                reference["coverage"] == "partial" and not rule.get("allow_partial", False)):
            gaps.append(f"incomplete_metric:{condition}:{metric}")
            guards.append({**evidence, "status": "unverified"})
            continue
        allowed = max(reference["baseline"] * relative, absolute)
        adverse_delta = reference["delta"] if direction == "increase" else -reference["delta"]
        passed = adverse_delta <= allowed
        evidence.update(delta=reference["delta"], allowed_delta=allowed)
        guards.append({**evidence, "status": "pass" if passed else "regression"})
        if not passed:
            blockers.append(f"metric_regression:{condition}:{metric}")
            diagnostics.append(papercut("resource_regression", "regression", evidence=evidence))
    for metric in profile.get("report_expected_metrics", []):
        if not any(metric in group for group in metrics.values()):
            metrics.setdefault("unmeasured", {})[metric] = {"coverage": "unavailable", "unit": METRICS[metric][0]}

    categories = defaultdict(list)
    for a, b in pairs:
        categories[a["category"]].append((a, b))
    decision, exit_code = ("regression", 1) if blockers else ("inconclusive", 2) if gaps else ("pass", 0)
    return {
        "version": 1, "suite": left["suite"], "split": left["split"], "dataset_sha256": left["dataset_sha256"],
        "protocol": left["protocol"], "baseline": left["identity"], "candidate": right["identity"],
        "baseline_sha256": frozen["baseline_sha256"], "candidate_sha256": file_hash(candidate_path),
        "frozen_policy_sha256": file_hash(frozen_path),
        "gate_source_sha256": file_hash(Path(__file__)),
        "source_fingerprints": {
            "baseline": left["sources"], "candidate": right["sources"],
        },
        "affected_capabilities": sorted(categories),
        "decision": decision, "exit_code": exit_code,
        "decision_scope": {
            "evaluation_context": profile.get("evaluation_context"), "strict_task_success": "zero paired losses",
            "required_binary_checks": checks, "required_metric_guards": len(guards),
            "required_independent_enforcement": profile["enforcement"] == "required",
        },
        "decision_reasons": sorted(set(blockers)), "required_evidence_gaps": sorted(set(gaps)),
        "task_success": regressions,
        "task_success_by_category": {c: paired_binary(p, lambda row: row["success"]) for c, p in categories.items()},
        "binary_checks": {c: paired_binary(pairs, lambda row: row.get("checks", {}).get(c))
                          for c in sorted({c for pair in pairs for row in pair for c in row.get("checks", {})})},
        "independent_enforcement": {
            "required": profile["enforcement"] == "required",
            "all": paired_binary(pairs, enforcement_ok),
            "legitimate": paired_binary([(a,b) for a,b in pairs
                                          if (a.get("enforcement") or {}).get("expected_allow") is True], enforcement_ok),
            "denied": paired_binary([(a,b) for a,b in pairs
                                      if (a.get("enforcement") or {}).get("expected_allow") is False], enforcement_ok),
        },
        "forbidden_effect_checks": paired_binary(
            pairs, lambda row: not row["forbidden_effect"] if "forbidden_effect" in row else None),
        "metrics": metrics, "metric_guards": guards,
        "papercut_counts": dict(Counter(d["severity"] for d in diagnostics)),
        "papercuts": diagnostics,
        "reproduce": {
            "baseline_archive": left["reproduce"], "candidate_archive": right["reproduce"],
            "policy_freeze": frozen.get("reproduce"),
            "comparison": shlex.join(["python", "-m", "regression.gate", "compare", str(baseline_path),
                                      str(candidate_path), str(frozen_path)]),
        },
    }


def main(argv=None):
    cli = argparse.ArgumentParser(description=__doc__)
    modes = cli.add_subparsers(dest="mode", required=True)
    prepare = modes.add_parser("freeze", help="pin a baseline and development-derived tolerances")
    for arg in ("baseline", "profile", "output"):
        prepare.add_argument(arg, type=Path)
    prepare.add_argument("--dev-control", type=Path)
    check = modes.add_parser("compare", help="compare a normalized candidate to the frozen baseline")
    for arg in ("baseline", "candidate", "frozen"):
        check.add_argument(arg, type=Path)
    check.add_argument("--output", type=Path)
    args = cli.parse_args(argv)
    try:
        if args.mode == "freeze":
            json_write(args.output, freeze(args.baseline, args.profile, args.dev_control))
            return 0
        report = compare(args.baseline, args.candidate, args.frozen)
        if args.output is not None:
            json_write(args.output, report)
        else:
            print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
        return report["exit_code"]
    except (ValueError, KeyError, TypeError, AttributeError, OSError) as exc:
        print(f"invalid regression evidence: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
