"""Paired inference at the scenario level. Inputs use matching case order."""
import math
import random
from statistics import mean


def bootstrap(left, right, clusters=None, *, seed=17, draws=10000):
    if not left or len(left) != len(right) or draws < 2:
        raise ValueError("paired nonempty samples and at least two draws required")
    labels = list(range(len(left))) if clusters is None else list(clusters)
    if len(labels) != len(left):
        raise ValueError("one cluster label per pair required")
    groups = {}
    for label, a, b in zip(labels, left, right, strict=True):
        groups.setdefault(label, []).append(b - a)
    blocks = list(groups.values())
    rng = random.Random(seed)
    samples = sorted(mean(v for block in rng.choices(blocks, k=len(blocks)) for v in block) for _ in range(draws))
    return mean(b-a for a,b in zip(left,right)), samples[int(.025*(draws-1))], samples[math.ceil(.975*(draws-1))]


def mcnemar(left, right):
    if not left or len(left) != len(right) or any(x not in (0, 1) for x in [*left, *right]):
        raise ValueError("paired binary observations required")
    a = sum(x and not y for x, y in zip(left, right))
    b = sum(y and not x for x, y in zip(left, right))
    n = a + b
    return min(1.0, 2 * sum(math.comb(n,k) for k in range(min(a,b)+1)) / 2**n)
